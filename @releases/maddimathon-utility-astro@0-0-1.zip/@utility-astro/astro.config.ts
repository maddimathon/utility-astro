import { defineConfig } from "astro/config";

import pkg from './package.json';

export const homeURL = new URL( pkg.homepage );
export const site: string = homeURL.origin;
export const base: string = homeURL.pathname;

export default defineConfig( {
    site: site,
    base: base,
    ...pkg.config.astro,
} );
// export default defineConfig( {
//     site: "https://dev.maddimathon.com", // domain/subdomain
//     base: "/maddi-is-gay", // 'root' path (e.g., /2023/** on the demo site)
//     srcDir: "./src/docs",
//     publicDir: "./src/docs/_public",
//     outDir: "./docs",
//     build: {
//         assets: "files",
//         client: "files/js",
//         format: "file",
//     },
//     server: { port: 8080, host: false },
//     compressHTML: true,
//     markdown: {
//         syntaxHighlight: 'prism',
//     },
// } );
